"""
parsers.py - Turns raw log lines into structured Python dictionaries.

Every parser returns a dict with the SAME set of keys (a "normalized record"),
no matter which log format it came from. That way the database and every
later tool only has to understand one shape of data.

Supported formats:
  - access : Apache / Nginx "combined" or "common" web server logs
  - syslog : Linux syslog / auth.log style lines (sshd, sudo, cron, etc.)
"""

import re
from datetime import datetime

# ---------------------------------------------------------------------------
# Regular expressions
# ---------------------------------------------------------------------------
# (?P<name>...) is a "named group": whatever matches inside it can be pulled
# out later by name with match.groupdict(). \S+ means "one or more
# non-space characters".

# Example line:
# 203.0.113.9 - - [04/Oct/2026:09:14:07 -0500] "GET /index.html HTTP/1.1" 200 5120 "-" "Mozilla/5.0"
ACCESS_PATTERN = re.compile(
    r'(?P<ip>\S+) \S+ (?P<user>\S+) '            # client IP, ident (ignored), user
    r'\[(?P<time>[^\]]+)\] '                     # [timestamp]
    r'"(?P<method>[A-Z]+) (?P<path>\S+) '        # "GET /path
    r'(?P<protocol>[^"]+)" '                     # HTTP/1.1"
    r'(?P<status>\d{3}) (?P<size>\S+)'           # status code and response size
    r'(?: "(?P<referrer>[^"]*)" "(?P<user_agent>[^"]*)")?'  # optional extras
)

# Example line:
# Oct  4 09:15:02 webserver sshd[1234]: Failed password for root from 198.51.100.7 port 22 ssh2
SYSLOG_PATTERN = re.compile(
    r'(?P<time>[A-Z][a-z]{2}\s+\d{1,2} \d{2}:\d{2}:\d{2}) '  # Oct  4 09:15:02
    r'(?P<host>\S+) '                                       # hostname
    r'(?P<process>[\w\-/.]+)(?:\[(?P<pid>\d+)\])?: '        # sshd[1234]:
    r'(?P<message>.*)'                                      # everything else
)

# Finds an IPv4 address anywhere inside free text (used for syslog messages).
IP_IN_TEXT = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')

# The full list of fields every normalized record has.
RECORD_FIELDS = (
    "source", "timestamp", "ip", "host", "process",
    "method", "path", "status", "bytes", "user_agent", "message",
)


def empty_record(source):
    """Start a record with every field set to None."""
    record = {field: None for field in RECORD_FIELDS}
    record["source"] = source
    return record


# ---------------------------------------------------------------------------
# Timestamp helpers - always convert to ISO 8601 so times sort correctly
# ---------------------------------------------------------------------------

def _access_time_to_iso(raw_time):
    """'04/Oct/2026:09:14:07 -0500' -> '2026-10-04T09:14:07'

    We drop the timezone offset so these times line up with syslog times
    (which never include one). Both are then the server's local time.
    """
    try:
        parsed = datetime.strptime(raw_time, "%d/%b/%Y:%H:%M:%S %z")
        return parsed.replace(tzinfo=None).isoformat()
    except ValueError:
        return raw_time  # keep the original rather than lose it


def _syslog_time_to_iso(raw_time):
    """'Oct  4 09:15:02' -> '2026-10-04T09:15:02'

    Classic syslog lines don't include a year, so we assume the current one.
    """
    try:
        cleaned = " ".join(raw_time.split())  # collapse double spaces
        parsed = datetime.strptime(cleaned, "%b %d %H:%M:%S")
        return parsed.replace(year=datetime.now().year).isoformat()
    except ValueError:
        return raw_time


# ---------------------------------------------------------------------------
# Parsers
# ---------------------------------------------------------------------------

def parse_access_line(line):
    """Parse one web server access log line. Returns a dict, or None if it doesn't match."""
    match = ACCESS_PATTERN.match(line)
    if not match:
        return None
    g = match.groupdict()

    record = empty_record("access")
    record.update({
        "timestamp": _access_time_to_iso(g["time"]),
        "ip": g["ip"],
        "method": g["method"],
        "path": g["path"],
        "status": int(g["status"]),
        "bytes": int(g["size"]) if g["size"].isdigit() else 0,  # size can be "-"
        "user_agent": g.get("user_agent"),
        "message": f'{g["method"]} {g["path"]} -> {g["status"]}',
    })
    return record


def parse_syslog_line(line):
    """Parse one syslog / auth.log line. Returns a dict, or None if it doesn't match."""
    match = SYSLOG_PATTERN.match(line)
    if not match:
        return None
    g = match.groupdict()

    # Syslog has no dedicated IP column, so grab the first IP mentioned in the message.
    ip_match = IP_IN_TEXT.search(g["message"])

    record = empty_record("syslog")
    record.update({
        "timestamp": _syslog_time_to_iso(g["time"]),
        "ip": ip_match.group(0) if ip_match else None,
        "host": g["host"],
        "process": g["process"],
        "message": g["message"],
    })
    return record


# Maps a format name to the function that parses it. Adding a new log type
# later is as simple as writing a parser and adding one line here.
PARSERS = {
    "access": parse_access_line,
    "syslog": parse_syslog_line,
}


def parse_line(line, fmt="auto"):
    """Parse a line using a specific format, or try each format when fmt='auto'."""
    line = line.rstrip("\n")
    if not line.strip():
        return None

    if fmt != "auto":
        return PARSERS[fmt](line)

    for parser in PARSERS.values():
        record = parser(line)
        if record:
            return record
    return None
