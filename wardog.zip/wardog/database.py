"""
database.py - Everything that touches the SQLite database lives here.

SQLite is a full SQL database stored in a single file (wardog.db by default).
It ships with Python, so there is nothing to install or run in the background.
"""

import hashlib
import sqlite3

from parsers import RECORD_FIELDS

# "IF NOT EXISTS" makes this safe to run every time the program starts.
SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    line_hash   TEXT UNIQUE NOT NULL,      -- fingerprint used to skip duplicates
    source      TEXT NOT NULL,             -- 'access' or 'syslog'
    timestamp   TEXT,                      -- ISO 8601 time of the event
    ip          TEXT,
    host        TEXT,
    process     TEXT,
    method      TEXT,
    path        TEXT,
    status      INTEGER,
    bytes       INTEGER,
    user_agent  TEXT,
    message     TEXT,
    raw         TEXT NOT NULL,             -- the original, untouched log line
    source_file TEXT,
    ingested_at TEXT DEFAULT (datetime('now'))
);

-- Indexes make searching by these columns fast, even with millions of rows.
CREATE INDEX IF NOT EXISTS idx_events_ip        ON events(ip);
CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp);
CREATE INDEX IF NOT EXISTS idx_events_source    ON events(source);

-- Findings are the security alerts produced by detection.py.
CREATE TABLE IF NOT EXISTS findings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    signature   TEXT UNIQUE NOT NULL,      -- stable identity, used to dedupe
    rule        TEXT NOT NULL,             -- which rule fired
    severity    TEXT NOT NULL,             -- critical / high / medium / low / info
    ip          TEXT,
    title       TEXT NOT NULL,
    detail      TEXT,
    event_count INTEGER DEFAULT 1,
    first_seen  TEXT,
    last_seen   TEXT,
    status      TEXT DEFAULT 'open',       -- open / acknowledged
    updated_at  TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_findings_status ON findings(status);
"""

INSERT_COLUMNS = ("line_hash",) + RECORD_FIELDS + ("raw", "source_file")


def connect(db_path):
    """Open (or create) the database and make sure the table exists."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row  # lets us access columns by name: row["ip"]
    conn.executescript(SCHEMA)
    return conn


def make_line_hash(source_file, line_number, raw):
    """Create a fingerprint for one log line.

    Including the file and line number means running ingest twice on the
    same file won't create duplicates, but re-running it after the file
    grows WILL pick up the new lines at the end.
    """
    key = f"{source_file}|{line_number}|{raw}"
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def insert_events(conn, rows):
    """Insert many rows at once. Returns how many were actually new.

    'INSERT OR IGNORE' quietly skips any row whose line_hash already exists.
    """
    placeholders = ", ".join("?" for _ in INSERT_COLUMNS)
    sql = f"INSERT OR IGNORE INTO events ({', '.join(INSERT_COLUMNS)}) VALUES ({placeholders})"

    before = conn.total_changes
    conn.executemany(sql, ([row[col] for col in INSERT_COLUMNS] for row in rows))
    conn.commit()
    return conn.total_changes - before


def search_events(conn, ip=None, source=None, status=None, text=None, limit=50):
    """Build a SELECT query from whichever filters were given.

    Values are passed separately as '?' parameters - never pasted into the
    SQL string - which protects against SQL injection.
    """
    conditions, params = [], []
    if ip:
        conditions.append("ip = ?")
        params.append(ip)
    if source:
        conditions.append("source = ?")
        params.append(source)
    if status is not None:
        conditions.append("status = ?")
        params.append(status)
    if text:
        conditions.append("raw LIKE ?")
        params.append(f"%{text}%")

    where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    sql = f"SELECT * FROM events {where} ORDER BY timestamp DESC LIMIT ?"
    params.append(limit)
    return conn.execute(sql, params).fetchall()


def get_stats(conn, top=10):
    """Summary numbers for the 'stats' command."""
    q = conn.execute
    return {
        "total": q("SELECT COUNT(*) FROM events").fetchone()[0],
        "by_source": q(
            "SELECT source, COUNT(*) AS n FROM events GROUP BY source ORDER BY n DESC"
        ).fetchall(),
        "top_ips": q(
            "SELECT ip, COUNT(*) AS n FROM events WHERE ip IS NOT NULL "
            "GROUP BY ip ORDER BY n DESC LIMIT ?", (top,)
        ).fetchall(),
        "status_codes": q(
            "SELECT status, COUNT(*) AS n FROM events WHERE status IS NOT NULL "
            "GROUP BY status ORDER BY status"
        ).fetchall(),
        "top_processes": q(
            "SELECT process, COUNT(*) AS n FROM events WHERE process IS NOT NULL "
            "GROUP BY process ORDER BY n DESC LIMIT ?", (top,)
        ).fetchall(),
        "time_range": q(
            "SELECT MIN(timestamp), MAX(timestamp) FROM events"
        ).fetchone(),
    }


def get_dashboard_data(conn, top=8, recent=10):
    """Everything the dashboard needs, gathered in one place.

    Note the SQL tricks:
      - COUNT(DISTINCT ip) counts unique values instead of rows.
      - SUM(CASE WHEN ... THEN 1 ELSE 0 END) counts only rows matching a
        condition, letting us compute several counts in one pass.
      - substr(timestamp, 1, 13) chops '2026-10-04T09:14:07' down to
        '2026-10-04T09' so we can GROUP BY hour.
    """
    q = conn.execute
    summary = q("""
        SELECT
            COUNT(*)                                                      AS total,
            COUNT(DISTINCT ip)                                            AS unique_ips,
            SUM(CASE WHEN message LIKE 'Failed password%' THEN 1 ELSE 0 END) AS failed_logins,
            SUM(CASE WHEN status BETWEEN 400 AND 499 THEN 1 ELSE 0 END)   AS client_errors,
            SUM(CASE WHEN status >= 500 THEN 1 ELSE 0 END)                AS server_errors,
            MIN(timestamp)                                                AS first_seen,
            MAX(timestamp)                                                AS last_seen
        FROM events
    """).fetchone()

    return {
        "summary": summary,
        "top_ips": q(
            "SELECT ip, COUNT(*) AS n FROM events WHERE ip IS NOT NULL "
            "GROUP BY ip ORDER BY n DESC LIMIT ?", (top,)
        ).fetchall(),
        "status_codes": q(
            "SELECT status, COUNT(*) AS n FROM events WHERE status IS NOT NULL "
            "GROUP BY status ORDER BY status"
        ).fetchall(),
        "by_hour": q(
            "SELECT substr(timestamp, 1, 13) AS hour, COUNT(*) AS n FROM events "
            "WHERE timestamp IS NOT NULL GROUP BY hour ORDER BY hour DESC LIMIT 12"
        ).fetchall()[::-1],  # newest 12 hours, flipped back into time order
        "recent": q(
            "SELECT timestamp, source, ip, status, message FROM events "
            "ORDER BY timestamp DESC LIMIT ?", (recent,)
        ).fetchall(),
        "findings": get_findings(conn, status="open", limit=12),
    }


# ---------------------------------------------------------------------------
# Findings (security alerts)
# ---------------------------------------------------------------------------

# Sort severity text in the right order without a separate rank column.
SEVERITY_SQL_ORDER = (
    "CASE severity WHEN 'critical' THEN 4 WHEN 'high' THEN 3 "
    "WHEN 'medium' THEN 2 WHEN 'low' THEN 1 ELSE 0 END"
)

UPSERT_FINDING = """
    INSERT INTO findings
        (signature, rule, severity, ip, title, detail, event_count,
         first_seen, last_seen, updated_at)
    VALUES
        (:signature, :rule, :severity, :ip, :title, :detail, :event_count,
         :first_seen, :last_seen, datetime('now'))
    ON CONFLICT(signature) DO UPDATE SET
        severity    = excluded.severity,
        title       = excluded.title,
        detail      = excluded.detail,
        event_count = excluded.event_count,
        last_seen   = excluded.last_seen,
        updated_at  = datetime('now')
"""


def save_findings(conn, findings):
    """Insert new findings, update existing ones. Returns the list of NEW ones.

    'ON CONFLICT(signature) DO UPDATE' is an UPSERT: if a finding with this
    signature already exists, refresh its counts and last_seen instead of
    inserting a duplicate. We check which signatures existed beforehand so we
    can tell the caller what's genuinely new (handy for monitor alerts).
    """
    existing = {
        row["signature"]
        for row in conn.execute("SELECT signature FROM findings").fetchall()
    }
    new = [f for f in findings if f["signature"] not in existing]
    conn.executemany(UPSERT_FINDING, findings)
    conn.commit()
    return new


def get_findings(conn, status="open", limit=200):
    """Return stored findings, most severe (then most recent) first."""
    where = "WHERE status = ?" if status else ""
    params = ([status] if status else []) + [limit]
    return conn.execute(
        f"SELECT * FROM findings {where} "
        f"ORDER BY {SEVERITY_SQL_ORDER} DESC, last_seen DESC LIMIT ?",
        params,
    ).fetchall()


def acknowledge_finding(conn, finding_id):
    """Mark one finding as handled so it drops off the active view.

    Returns True if a row was actually changed.
    """
    cur = conn.execute(
        "UPDATE findings SET status = 'acknowledged', updated_at = datetime('now') "
        "WHERE id = ? AND status = 'open'",
        (finding_id,),
    )
    conn.commit()
    return cur.rowcount > 0


def count_open_findings(conn):
    """How many open findings, and how many of them are critical/high."""
    row = conn.execute(
        """
        SELECT COUNT(*) AS total,
               SUM(CASE WHEN severity IN ('critical','high') THEN 1 ELSE 0 END) AS severe
        FROM findings WHERE status = 'open'
        """
    ).fetchone()
    return {"total": row["total"] or 0, "severe": row["severe"] or 0}
